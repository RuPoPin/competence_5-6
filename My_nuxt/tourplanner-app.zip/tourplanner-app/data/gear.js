export const gearList = [
  { id: 1, name: 'Палатка', category: 'Снаряжение', checked: false },
  { id: 2, name: 'Спальный мешок', category: 'Снаряжение', checked: false },
  { id: 3, name: 'Коврик (каремат)', category: 'Снаряжение', checked: false },
  { id: 4, name: 'Рюкзак (60-80л)', category: 'Снаряжение', checked: false },
  { id: 5, name: 'Треккинговые ботинки', category: 'Одежда и обувь', checked: false },
  { id: 6, name: 'Куртка ветрозащитная/влагозащитная', category: 'Одежда и обувь', checked: false },
  { id: 7, name: 'Флисовая кофта', category: 'Одежда и обувь', checked: false },
  { id: 8, name: 'Горелка и топливо', category: 'Кухня', checked: false },
  { id: 9, name: 'Котелок, кружка, ложка, нож', category: 'Кухня', checked: false },
  { id: 10, name: 'Фонарик (налобный)', category: 'Разное', checked: false },
  { id: 11, name: 'Аптечка первой помощи', category: 'Разное', checked: false },
  { id: 12, name: 'Карта и компас/GPS', category: 'Навигация', checked: false },
];